import React from 'react'
import "./PageNotFound.css"
function PageNotFound() {
  return (
    <div className='pageNotFound' > 404. Error<br></br> PageNotFound</div>
  )
}

export default PageNotFound